#include<bits/stdc++.h>
using namespace std;
FILE * vocabtraining=fopen("vocabulary.txt","r");
FILE *vocabtrainbg=fopen("bigramvocab.txt","r");
FILE *uniprob=fopen("uniprob.txt","w");
FILE *bgprob=fopen("bgprob.txt","w");
struct vocab
{
	char str[100];
	int cp,cn;
	double pp,pn;
}store[5000];
int main()
{
	int i,j,len,cp,cn,bcp,bcn,vocabsize=0,posrev=0,negrev=0,accuracycount=0,posinbg=0,posinug=0,neginbg=0,neginug=0;	//count pos, count negative 
	double pp,pn,bpp,bpn,pps,pns,priorpp,priorpn;				//prob pos,  prob negative, s stands for sentance
	char str[5000],sign,word[100],s[5000],w1[5000],w2[5000];
	//cout<<"Hello";
	i=0;
	cout<<"hello";
	while(!feof(vocabtraining))
	{
		fscanf(vocabtraining,"%s %d %d",s,&cp,&cn);
		strcpy(store[i].str,s);
		store[i].cp=cp;
		store[i].cn=cn;
		posinug+=cp;
		neginug+=cn;
		i++;
	}
	int m,k;
	m=i;
	while(!feof(vocabtrainbg))
	{
		fscanf(vocabtrainbg,"%s %s %d %d",w1,w2,&bcp,&bcn);
		posinbg+=bcp;
		neginbg+=bcn;
		for(k=0;k<m;k++)
		{
			if(strcmp(w1,store[k].str)==0)
			{
				store[k].cp-=bcp;
				store[k].cn-=bcn;
			}
			if(strcmp(w2,store[k].str)==0)
			{
				store[k].cp-=bcp;
				store[k].cn-=bcn;
			}
			
		}
				
		strcat(w1," ");
		strcat(w1,w2);
		strcpy(store[i].str,w1);
		store[i].cp=bcp;
		store[i].cn=bcn;
		i++;
	}
	int tot;
	tot=i;
	cout<<"vocabulary count of uni and bigram are "<<endl;
	cout<<m<<" "<<tot-m<<endl;
	for(i=0;i<m;i++)
	{
		float probpos= (float) (store[i].cp +1)/(posinug+m);
		float probneg= (float) (store[i].cn +1)/(neginug+m);
		fprintf(uniprob,"%s %d %d %lf %lf\n",store[i].str,store[i].cp,store[i].cn,probpos,probneg);
	}
	for(i=m;i<tot;i++)
	{
		float probpos= (float) (store[i].cp +1)/(posinbg+tot-m);
		float probneg= (float) (store[i].cn +1)/(neginbg+tot-m);
		fprintf(bgprob,"%s %d %d %lf %lf\n",store[i].str,store[i].cp,store[i].cn,probpos,probneg);
	}
	return 0;
}
