#include<bits/stdc++.h>
using namespace std;
char sign;
int totalpos=0,totalneg=0;
FILE *vocab=fopen("bigramvocab.txt","w");
//structure of BST
struct node
{
	char str[100];					//word
	int countpos,countneg;						//occurence of word
	struct node* left,*right;
};
struct node*insert(struct node*root,struct node*temp)
{
		if(root==NULL )
		{
			if(sign=='+')
				temp->countpos++;
			else if(sign=='-')
				temp->countneg++;
			return temp;
		}
		//condition if word already exist in the tree.
		if(strcmp(temp->str,root->str)==0)
		{
			if(sign=='+')
				root->countpos++;
			else if(sign=='-')
				root->countneg++;
			return root;
		}
		if(strcmp(temp->str,root->str)<0)
			root->left= insert(root->left,temp);
		else
			root->right= insert(root->right,temp);
	return root;
}
//fuction to return new node.
struct node*getnode(char *word)
{
	struct node*temp=(struct node*)malloc(sizeof(struct node));
	strcpy(temp->str,word);
	temp->right=temp->left=NULL;
	temp->countpos=temp->countneg=0;
	return temp;
}
//function to perform inorder traversal and inserting the file vocabulary.txt
void inorder(struct node*root)
{
	if(root)
	{
		inorder(root->left);
		//if(root->countpos && root->countneg)
		if(root->countneg+root->countpos>=3)
			fprintf(vocab,"%s %d %d\n",root->str,root->countpos,root->countneg);
		if(root->countneg)
			totalneg++;
		if(root->countpos)
			totalpos++;
		//cout<<root->str<<root->countpos<<root->countneg<<endl;
		inorder(root->right);
	}
}
int main()
{
	struct node*root=NULL,*temp;
	int i,j,pos=0,neg=0;
	char word[100],str[1000];
	FILE *fp=fopen("new.txt","a+");
	//FILE *bigram=fopen("bigramvocab.txt","a+");
	//reading words from file and inserting each word in a BST.
	while(1)
	{
		fgets(str,999,fp);
		//fscanf(fp,"%c",&sign);
		sign=str[0];
		if(sign=='+')
			pos++;
		else if(sign=='-')
			neg++;

		//cout<<sign;
		//fscanf(fp,"%s",word);
		//cout<<word;
		//fgets(str,999,fp);
		cout<<strlen(str);
		cout<<(int)str[strlen(str)]<<" ";
		cout<<(int)str[strlen(str)-1]<<" ";
		cout<<(int)str[strlen(str)-2]<<" ";
		cout<<(int)str[strlen(str)-3]<<" ";
		cout<<(int)str[strlen(str)-4]<<" ";
		if(str[strlen(str)-2]==' '){
			cout<<"Hi";
			str[strlen(str)-2]='\0';
		}
		i=0;
		int k,l;	
		//processing each line
		for(i=2;str[i]!='\0';i++)
		{
			j=0;
			//reading word by word
			while((str[i]<='z' && str[i]>='a') || str[i]==39)
				word[j++]=str[i++];
			
			if(str[i]=='\0')
			{
				word[0]='\0';
				break;
			}
			word[j++]=str[i++];
			k=i;
			while((str[i]<='z' && str[i]>='a') || str[i]==39)
				word[j++]=str[i++];
			word[j]='\0';
			i=k-1;
			for(l=0;l<strlen(word);l++)
			{
				if(word[l]==' '&&word[l+1]!=' '){
					temp = getnode(word);
					root = insert(root,temp);
//cout<<word<<" ";	
					break;
				}

			}
			
			//temp = getnode(word);
		//root = insert(root,temp);
		}
		if(feof(fp)) break;
		
	}
	inorder(root);
	
	cout<<pos<<" "<<neg<<endl;
	cout<<totalpos<<" "<<totalneg<<endl;
	return 0;
}
