#include<bits/stdc++.h>
using namespace std;
FILE * vocabtraining=fopen("uniprob.txt","a+");
FILE *vocabtrainbg=fopen("bgprob.txt","a+");
FILE * train=fopen("tr1.txt","a+");
FILE * test=fopen("ts1.txt","a+");
FILE * accu=fopen("accuracy.txt","a+");
struct vocab
{
	char str[100];
	int cp,cn;
	double pp,pn;
}store[5000];
int main()
{
	int i,flag,t,j,k,len,cp,cn,bcp,bcn,vocabsize=0,posrev=0,negrev=0,accuracycount=0;	//count pos, count negative 
	double pp,pn,bpp,bpn,pps,pns,priorpp,priorpn;				//prob pos,  prob negative, s stands for sentance
	char str[5000],sign,word[100],word2[100],s[5000],w1[5000],w2[5000];
	//cout<<"Hello";
	i=0;
	while(!feof(vocabtraining))
	{
		fscanf(vocabtraining,"%s %d %d %lf %lf",s,&cp,&cn,&pp,&pn);
		strcpy(store[i].str,s);
		store[i].cp=cp;
		store[i].cn=cn;
		store[i].pp=pp;
		store[i].pn=pn;
		i++;
	}
	int m;
	m=i;
	while(!feof(vocabtrainbg))
	{
		//cout<<"in the while";
		fscanf(vocabtrainbg,"%s %s %d %d %lf %lf",w1,w2,&bcp,&bcn,&bpp,&bpn);		
		strcat(w1," ");
		strcat(w1,w2);
		strcpy(store[i].str,w1);
		store[i].cp=bcp;
		store[i].cn=bcn;
		store[i].pp=bpp;
		store[i].pn=bpn;
		i++;
	}
	//cout<<"HIIIII";
	vocabsize=i;
	/*for(i=0;i<100;i++)
	{
		cout<<store[i].str<<" "<<store[i].pp<<endl;
	}*/
	int posword,negword;
	posword=negword=0;
	while(!feof(train))
	{
		fgets(str,9999,train);
		//cout<<str<<endl;
		if(str[0]=='+')
			posrev++;
		else if(str[0]=='-')
			negrev++;
		len=strlen(str);
		//cout<<len<<" ";
		for(i=2;i<len;i++)
		{
			j=0;
			while((str[i]<='z' && str[i]>='a') || str[i]==39)
				word[j++]=str[i++];
			word[j]='\0';
			if(str[0]=='+')
				posword++;
			else if(str[0]=='-')
				negword++;
			
		}	
		//cout<<posword<<" "<<negword<<endl;
	}
	//cout<<"posword and negwords";
	//cout<<posword<<" "<<negword<<endl;
	priorpp=posrev/450.0;
	priorpn=negrev/450.0;
	//cout<<"prior probability"<<priorpp<<" "<<priorpn<<endl;
	/*while(!feof(vocabtraining))
	{
		fscanf(vocabtraining,"%s %d %d %lf %lf",s,&cp,&cn,&pp,&pn);
		//vocabsize++;
		cout<<s<<" "<<cp<<" "<<cn<<" "<<pp<<" "<<pn<<endl;
	}*/
	//cout<<posrev<<" "<<negrev<<endl;
	//cout<<"HELLO";

	//cout<<"vocabsize is"<<vocabsize<<endl;
	//cout<<"HELLO\n\n";
	
	while(!feof(test))
	{
		//cout<<"HELLO";
		j=0;
		pps=priorpp;
		pns=priorpn;
		//cout<<"priors "<<pps<<" "<<pns<<endl<<endl;
		fgets(str,9990,test);
		len=strlen(str);
		/*cout<<(int)str[strlen(str)]<<" ";
		cout<<(int)str[strlen(str)-1]<<" ";
		cout<<(int)str[strlen(str)-2]<<" ";
		cout<<(int)str[strlen(str)-3]<<" ";
		cout<<str<<endl;*/
		if(str[strlen(str)-3]==' ')
		{
			//cout<<"Hi";
			str[strlen(str)-3]='\0';
		}
		//cout<<str<<endl;
		sign=str[0];
		//cout<<sign<<endl;
		//cout<<str[2];
		for(i=2;i<len;i++)
		{
			j=0;
			while((str[i]<='z' && str[i]>='a') || str[i]==39)
				word[j++]=str[i++];
			word[j]='\0';
		 	t=i;
		 	cout<<word<<endl;
		 	strcpy(word2,word);
		 	cout<<word2<<endl;
		 	//cout<<(int)str[t]<<endl;
		 	if(str[t]==32)
		 	{
		 		//cout<<"HELLO in if";
		 		word2[j]=str[t];	
		 		t++;
		 		j++;
		 		while(str[t]!='\0'&& str[t]!=32)
		 		{

		 			word2[j++]=str[t++];
		 			/*if(str[t]=='\0')
		 				break;
		 			if(str[t]==' ')
		 				break;*/
		 		}
		 	}	
		 	
		 	word2[j]='\0';
		 	//cout<<"after if";
		 	cout<<word2<<endl;
			//cout<<word<<" ";
			//cout<<"a";
			//cout<<feof(vocabtraining)<<endl;
			//cout<<"hello";
			flag=0;
			for(k=m;k<vocabsize;k++)
			{

				if(strcmp(store[k].str,word2)==0)
				{
					//cout<<"yeah\n";
					pps=pps*store[k].pp;
					pns=pns*store[k].pn;
					flag=1;
					//pps=(log(pps)+log(store[k].pp));
					//pns=(log(pns)+log(store[k].pn));
					//pps=antilog(pps);
					break;
				}
			}
			if(flag==0)
			{
				for(k=0;k<m;k++)
				{
					if(strcmp(store[k].str,word)==0)
					{
						//cout<<"yeah\n";
						pps=pps*store[k].pp;
						pns=pns*store[k].pn;
						flag=1;
						//pps=(log(pps)+log(store[k].pp));
						//pns=(log(pns)+log(store[k].pn));
						//pps=antilog(pps);
						break;
					}
				}
			}	
			if(flag==0)
			{
				//cout<<"s ";
				pps=pps*(1.0/(posword+vocabsize));
				pns=pns*(1.0/(negword+vocabsize));
				//cout<<pps<<" "<<pns<<endl;
			}
			/*while(!feof(vocabtraining))
			{
				fscanf(vocabtraining,"%s %d %d %lf %lf",s,&cp,&cn,&pp,&pn);
				if(strcmp(s,word))
				{
					pps=pps*pp;
					pns=pns+pn;
				}
				cout<<pps<<" "<<pns<<endl;
				cout<<s<<" "<<cp<<" "<<cn<<" "<<pp<<" "<<pn<<endl;
			}*/
			
		}
		cout<<"HELLOO";
	
//		cout<<pps<<"  "<<pns<<endl;
		cout<<setprecision(15)<<pps<<" "<<pns<<" "<<sign<<endl;
		if(pps>pns && sign=='+')
		{
			accuracycount++;
			//cout<<str<<endl;
	//		cout<<"positive"<<sign<<endl;
		}
		else if(pps<pns && sign=='-')
		{
			accuracycount++;
			//cout<<str<<endl;
	//		cout<<"negative"<<sign<<endl;
		}
		else cout<<str<<endl;	
		cout<<endl;
	}
	cout<<"Accuracy "<<accuracycount<<endl;
	fprintf(accu, "acc = %d vocabsize=%d\n",accuracycount,vocabsize);
	return 0;
}
